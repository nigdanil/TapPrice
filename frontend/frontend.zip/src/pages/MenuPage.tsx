export default function MenuPage() {
  return (
    <div>
      <h1>Меню</h1>
      <p>Здесь отображаются продукты, категории и т.д.</p>
    </div>
  )
}

